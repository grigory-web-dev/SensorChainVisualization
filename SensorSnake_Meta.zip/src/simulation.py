# simulation.py
class PlatesSimulation:
    def __init__(self, config: SimConfig):
        self.config = config
        self.plates = []
        self.velocities = []
        
        # Инициализация начальных позиций
        self.initialize_plates()
        
    def initialize_plates(self):
        """Инициализация пластин с начальными позициями"""
        plate_length = self.config.BASE_LENGTH
        plate_width = plate_length * self.config.WIDTH_RATIO
        
        for i in range(self.config.NUM_PLATES):
            # Начальное положение пластины
            x = i * (plate_length * 0.9)  # 90% перекрытие
            y = plate_length * 0.5  # Подъём над столом
            z = 0
            
            plate = Plate(
                center=(x, y, z),
                angles=(0.0, 0.0, 0.0),
                width=plate_width,
                length=plate_length,
                index=i
            )
            self.plates.append(plate)
            # Начальные скорости
            self.velocities.append(np.zeros(3))
        
        server_logger.info(f"Initialized {len(self.plates)} plates")

    def update_joint_constraints(self):
        """Обновление ограничений соединений между пластинами"""
        for i in range(len(self.plates) - 1):
            plate1 = self.plates[i]
            plate2 = self.plates[i + 1]
            
            # Желаемое расстояние между центрами пластин
            desired_distance = plate1.length * 0.9
            
            # Текущие позиции
            pos1 = np.array(plate1.center)
            pos2 = np.array(plate2.center)
            
            # Направление и расстояние
            direction = pos2 - pos1
            current_distance = np.linalg.norm(direction)
            
            if current_distance > 0:
                # Нормализованное направление
                direction = direction / current_distance
                
                # Коррекция позиций
                correction = (current_distance - desired_distance) * 0.5
                new_pos1 = pos1 + direction * correction
                new_pos2 = pos2 - direction * correction
                
                # Обновление позиций
                self.plates[i] = Plate(
                    center=tuple(new_pos1),
                    angles=plate1.angles,
                    width=plate1.width,
                    length=plate1.length,
                    index=plate1.index
                )
                self.plates[i + 1] = Plate(
                    center=tuple(new_pos2),
                    angles=plate2.angles,
                    width=plate2.width,
                    length=plate2.length,
                    index=plate2.index
                )

    def update(self):
        """Обновление состояния симуляции"""
        try:
            for i, plate in enumerate(self.plates):
                # Случайные ускорения
                acceleration = np.random.uniform(
                    -self.config.ANGLE_STEP,
                    self.config.ANGLE_STEP,
                    size=3
                )
                
                # Обновление скоростей с затуханием
                self.velocities[i] = [
                    v * self.config.DAMPING + a
                    for v, a in zip(self.velocities[i], acceleration)
                ]
                
                # Новые углы с ограничениями
                new_angles = tuple(
                    np.clip(a + v, self.config.MIN_ANGLE, self.config.MAX_ANGLE)
                    for a, v in zip(plate.angles, self.velocities[i])
                )
                
                # Обновление пластины
                self.plates[i] = Plate(
                    center=plate.center,
                    angles=new_angles,
                    width=plate.width,
                    length=plate.length,
                    index=plate.index
                )
            
            # Применение ограничений
            self.update_joint_constraints()
            
            # Проверка валидности
            if not is_valid_state(self.plates, self.config):
                # Уменьшение скоростей при невалидном состоянии
                self.velocities = [v * 0.5 for v in self.velocities]
                
        except Exception as e:
            server_logger.error(f"Error in simulation update: {e}")
            raise

    def get_state(self) -> SystemState:
        """Получение текущего состояния системы"""
        state = SystemState(
            timestamp=datetime.now(),
            plates=self.plates,
            plate_base_length=self.config.BASE_LENGTH,
            plate_width=self.config.BASE_LENGTH * self.config.WIDTH_RATIO
        )
        
        try:
            data_logger.info(json.dumps(state.to_dict()))
        except Exception as e:
            server_logger.error(f"Failed to log data: {e}")
            
        return state
